package de.lars.drugs.listener;

import de.lars.drugs.config.Configuration;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class RenameBlockListener implements Listener {
private Configuration config;
    public RenameBlockListener(Configuration config){
        this.config = config;
    }
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getInventory() instanceof AnvilInventory)) {
            return;
        }
        Player player = (Player) event.getWhoClicked();
        ItemStack item = event.getCurrentItem();

        if (item != null && item.getType() != Material.AIR) {
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                String newName = meta.getDisplayName();
                if (newName != null && (newName.equalsIgnoreCase(config.getString("weed_seed_name")) ||
                        newName.equalsIgnoreCase(config.getString("weed_name"))||
                        newName.equalsIgnoreCase(config.getString( "cocaine_name"))||
                        newName.equalsIgnoreCase(config.getString( "cocaine_seed_name"))||
                        newName.equalsIgnoreCase(config.getString("tobacco_seed_name"))||
                        newName.equalsIgnoreCase(config.getString("tobacco_name"))||
                        newName.equalsIgnoreCase(config.getString("cigarette_name"))||
                        newName.equalsIgnoreCase(config.getString("papes_name"))||
                        newName.equalsIgnoreCase(config.getString("long_papes_name"))||
                        newName.equalsIgnoreCase(config.getString("glue_bottle_name"))||
                        newName.equalsIgnoreCase(config.getString("zippo_name"))||
                        newName.equalsIgnoreCase(config.getString("shroom_name"))||
                        newName.equalsIgnoreCase(config.getString("lsd_name"))||
                        newName.equalsIgnoreCase(config.getString("lysergic_acid_name"))||
                        newName.equalsIgnoreCase(config.getString("sodium_name"))||
                        newName.equalsIgnoreCase(config.getString("propanolamine_name"))||
                        newName.equalsIgnoreCase(config.getString("hydrogen_name"))||
                        newName.equalsIgnoreCase(config.getString("xtc_name"))||
                        newName.equalsIgnoreCase(config.getString("isosafrole_name"))||
                        newName.equalsIgnoreCase(config.getString("safrole_name"))||
                        newName.equalsIgnoreCase(config.getString("piperonal_name")))) {
                    event.setCancelled(true);
                    player.sendMessage(ChatColor.RED + "You cannot fake your drugs!");
                }
            }
        }
    }
}