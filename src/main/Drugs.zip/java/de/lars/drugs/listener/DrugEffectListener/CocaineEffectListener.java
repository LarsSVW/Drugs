package de.lars.drugs.listener.DrugEffectListener;

import de.lars.drugs.config.Configuration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Random;

public class CocaineEffectListener implements Listener {

    private Configuration config;
    private double cocaine_kill;
    public CocaineEffectListener(Configuration config){
        this.config = config;
        this.cocaine_kill = config.getDouble("cocaine_kill");
    }
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getItemInHand();

        if (item != null && item.getType() == Material.SUGAR && item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_name", "§eCocaine") ))) {
            if (event.getAction().toString().contains("RIGHT_CLICK")) {
                int amount = item.getAmount();
                if (amount > 1) {
                    item.setAmount(amount - 1);
                } else {
                    player.setItemInHand(null);
                }
                applyEffects(player);
                Random random = new Random();
                if (random.nextDouble() < cocaine_kill) {
                    player.damage(2000);
                    Bukkit.getServer().broadcastMessage(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_death", "%player% died because of an cocaine overdose.").replace("%player%", player.getName())));
                }
            }
        }
    }

    private void applyEffects(Player player) {
        int time = config.getInt("cocaine_duration", 30);
        int duration = time * 20;
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByName(config.getString("cocaine_effect_1")), duration, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByName(config.getString("cocaine_effect_2")), duration, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByName(config.getString("cocaine_effect_3")), duration, 1));
    }
}
