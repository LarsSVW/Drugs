package de.lars.drugs.listener;

import de.lars.drugs.config.Configuration;
import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GrassBreakListener implements Listener {
    private Configuration config;
    private double dropChancecocaine;
    private double dropChanceTobacco;
    private double dropchanceweed;
    public GrassBreakListener(Configuration config){
        this.config = config;
        dropChancecocaine = config.getDouble("cocaine_chance");
        dropChanceTobacco = config.getDouble("tobacco_chance");
        dropchanceweed = config.getDouble("weed_chance");
    }
    @EventHandler
    public void onGrassBreak(BlockBreakEvent event) {
        if (event.getBlock().getType() == Material.GRASS) {
            Random random = new Random();
            if (random.nextDouble() < dropchanceweed) {
                ItemStack superSeed = getSuperSeedItem(1);
                event.getBlock().getWorld().dropItemNaturally(event.getBlock().getLocation(), superSeed);
            }
            if (random.nextDouble() < dropChancecocaine){
                ItemStack cocaineplant = getCocainePlantItem(1);
                event.getBlock().getWorld().dropItemNaturally(event.getBlock().getLocation(), cocaineplant);
            }
            if (random.nextDouble() < dropChanceTobacco){
                ItemStack tobaccoPlant = getTobaccoPlant(1);
                event.getBlock().getWorld().dropItemNaturally(event.getBlock().getLocation(), tobaccoPlant);
            }
        }
    }

    private ItemStack getSuperSeedItem(int amount) {
        ItemStack itemStack = new ItemStack(Material.WHEAT_SEEDS, amount);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("weed_seed_name", "§eWeed Seed")));
        List<String> lore = new ArrayList<>();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("weed_seed_lore", "§eYou can plant this seed to create new Weed")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }
    private ItemStack getCocainePlantItem(int amount) {
        ItemStack itemStack = new ItemStack(Material.WHEAT_SEEDS, amount);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_seed_name", "§eCocaine Seed")));
        List<String> lore = new ArrayList<>();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_seed_lore", "§eYou can use this seed to create new cocaine.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }
    private ItemStack getTobaccoPlant(int amount) {
        ItemStack itemStack = new ItemStack(Material.WHEAT_SEEDS, amount);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("tobacco_seed_name", "§eTobacco Seed")));
        List<String> lore = new ArrayList<>();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        lore.add(ChatColor.translateAlternateColorCodes('&',config.getString("tobacco_seed_lore", "§eYou can use this seed to create new Tobacco plant.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

}
