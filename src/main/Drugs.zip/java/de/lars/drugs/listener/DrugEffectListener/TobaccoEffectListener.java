package de.lars.drugs.listener.DrugEffectListener;

import de.lars.drugs.config.Configuration;
import de.lars.drugs.listener.DrugListener.TobaccoListener;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Random;

public class TobaccoEffectListener implements Listener {
    private double cigarettekill;
    private Configuration config;

    public TobaccoEffectListener(Configuration config){
        cigarettekill = config.getDouble("cigarette_kill");
        this.config = config;
    }
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();

        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }

        ItemStack item = player.getInventory().getItemInOffHand();
        if (item != null && item.getType() == Material.FLINT_AND_STEEL && item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', config.getString("zippo_name", "§eZippo")))) {
            ItemStack joint = player.getInventory().getItemInMainHand();

            if (joint != null && joint.getType() == Material.STICK && joint.hasItemMeta() && joint.getItemMeta().hasDisplayName() && joint.getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', config.getString("cigarette_name", "§eCigarette")))) {
                if (event.getAction().toString().contains("RIGHT_CLICK")) {
                    int amount = joint.getAmount();
                    if (amount > 1) {
                        joint.setAmount(amount - 1);
                    } else {
                        player.getInventory().setItemInMainHand(null);
                    }

                    applyEffects(player);
                    event.setCancelled(true);
                    Random random = new Random();
                    if (random.nextDouble() < cigarettekill) {
                        player.damage(2000);
                        Bukkit.getServer().broadcastMessage(ChatColor.translateAlternateColorCodes('&', config.getString("lung_cancer", "%player% died because of lung cancer!").replace("%player%", player.getName())));
                    }
                    return;
                }
            }
        }

        ItemStack joint = player.getInventory().getItemInMainHand();
        if (joint != null && joint.getType() == Material.STICK && joint.hasItemMeta() && joint.getItemMeta().hasDisplayName() && joint.getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', config.getString("cigarette_name", "§eCigarette")))) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', config.getString("need_zippo", "§eYou need a zippo to light this up.")));
        }
    }

    private void applyEffects(Player player) {
        int time = config.getInt("tobacco_time", 30);
        int duration = time * 20;
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByName(config.getString("tobacco_effect_1")), duration, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByName(config.getString("tobacco_effect_2")), duration, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByName(config.getString("tobacco_effect_3")), duration, 1));
    }
}

