package de.lars.drugs.listener;

import de.lars.drugs.config.Configuration;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ShroomBreakListener implements Listener {
    private Configuration config;
    private  double dropChanceshrooms; // 3% Chance


    public ShroomBreakListener(Configuration config){
        this.config = config;
        this.dropChanceshrooms = config.getDouble("shrooms_chance");
    }
    @EventHandler
    public void onGrassBreak(BlockBreakEvent event) {
        if (event.getBlock().getType() == Material.RED_MUSHROOM) {
            Random random = new Random();
            if (random.nextDouble() < dropChanceshrooms) {
                ItemStack shroomItem = getShroomItem(1);
                event.getBlock().getWorld().dropItemNaturally(event.getBlock().getLocation(), shroomItem);
            }

        }
    }

    private ItemStack getShroomItem(int amount) {
        ItemStack itemStack = new ItemStack(Material.RED_MUSHROOM, amount);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("shroom_name", "§eShroom")));
        List<String> lore = new ArrayList<>();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("shroom_lore", "§eYou can use it to get high.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }
}
