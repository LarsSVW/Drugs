package de.lars.drugs.listener.DrugEffectListener;

import de.lars.drugs.config.Configuration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Random;

public class EcstasyEffectListener implements Listener {
    private Configuration config;
    private double ecstasykill;
    public EcstasyEffectListener(Configuration config) {
        this.config = config;
        ecstasykill = config.getDouble("ecstasy_kill");
    }
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getItemInHand();

        if (item != null && item.getType() == Material.PAPER && item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', config.getString("xtc_name", "§eEcstasy") ))) {
            if (event.getAction().toString().contains("RIGHT_CLICK")) {
                int amount = item.getAmount();
                if (amount > 1) {
                    item.setAmount(amount - 1);
                } else {
                    player.setItemInHand(null);
                }

                applyEffects(player,config);
                Random random = new Random();
                if (random.nextDouble() < ecstasykill) {
                    player.damage(2000);
                    Bukkit.getServer().broadcastMessage(ChatColor.translateAlternateColorCodes('&', config.getString("ecstasy_death", "%player% died because of an ecstasy overdose.").replace("%player%", player.getName())));
                }
            }
        }
    }

    private void applyEffects(Player player, Configuration config) {
        int time = config.getInt("xtc_duration", 30);
        int duration = time * 20;
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByName(config.getString("xtc_effect_1")), duration, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByName(config.getString("xtc_effect_2")), duration, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByName(config.getString("xtc_effect_3")), duration, 1));
    }
}
