package de.lars.drugs.listener.DrugListener;

import de.lars.drugs.Drugs;
import de.lars.drugs.config.Configuration;
import de.lars.drugs.manager.CocaineManager;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.ArrayList;
import java.util.List;

public class CocaineListener implements Listener {
    private Configuration config;
    private final Drugs plugin;
    private CocaineManager cocaineManager;

    public CocaineListener(Drugs plugin, Configuration config) {
        this.config = config;
        this.plugin = plugin;
        this.cocaineManager = plugin.getCocaineManager();
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getItemInHand();
        if (item != null && item.getType() == Material.WHEAT_SEEDS && item.hasItemMeta()) {
            ItemMeta itemMeta = item.getItemMeta();
            if (itemMeta.hasDisplayName() && itemMeta.getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_seed_name", "§eCocaine Plant")))) {
                Block block = event.getBlock();
                cocaineManager.placeCocainePlant(block);
            }
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (block.getType() == Material.WHEAT && cocaineManager.isCocainePlant(block)) {
            boolean isFullyGrown = isFullyGrown(block);
            event.setCancelled(true);
            block.setType(Material.AIR);
            if (isFullyGrown) {
                block.getWorld().dropItemNaturally(block.getLocation(), getCocaineItem());
                block.getWorld().dropItemNaturally(block.getLocation(), getCocainePlant(2));
            } else {
                block.getWorld().dropItemNaturally(block.getLocation(), getCocainePlant(1));
            }
            block.removeMetadata("cocaine plant", plugin);
        }
    }

    private boolean isFullyGrown(Block block) {
        BlockData blockData = block.getBlockData();
        if (blockData instanceof Ageable) {
            Ageable ageable = (Ageable) blockData;
            return ageable.getAge() == ageable.getMaximumAge();
        }
        return false;
    }

    private ItemStack getCocaineItem() {
        ItemStack itemStack = new ItemStack(Material.SUGAR, 1);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_name", "§eCocaine")));
        List<String > lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_lore", "§eYou can consume it to feel high.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private ItemStack getCocainePlant(int amount) {
        ItemStack itemStack = new ItemStack(Material.WHEAT_SEEDS, amount);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_seed_name", "§eCocaine Plant")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_seed_lore","§eYou can use it to produce more Cocaine.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }
}