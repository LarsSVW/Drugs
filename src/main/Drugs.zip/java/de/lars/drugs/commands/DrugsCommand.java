package de.lars.drugs.commands;

import de.lars.drugs.config.Configuration;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class DrugsCommand implements CommandExecutor, TabCompleter {
    private Configuration config;

    public DrugsCommand(Configuration config) {
        this.config = config;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can execute this command.");
            return true;
        }

        Player player = (Player) sender;

        if (args.length < 4) {
            player.sendMessage("Usage: /drugs give <DRUG_TYPE> <DRUG> <AMOUNT>");
            return true;
        }
        if (!player.hasPermission("drugs.get")){
            player.sendMessage("§cNo Permission!");
            return  true;
        }

        String drug = args[2].toLowerCase();
        int amount;

        try {
            amount = Integer.parseInt(args[3]);
        } catch (NumberFormatException e) {
            player.sendMessage("Invalid amount specified.");
            return true;
        }

        ItemStack drugItem;
        String drugname = args[2];

        if (drug.equals("hydrogen")) {
            drugItem = createHydrogen(config);
        } else if (drug.equals("lsd")) {
            drugItem = createLSD(config);
        } else if (drug.equals("lysergicacid")) {
            drugItem = createLysergicAcid(config);
        } else if (drug.equals("sodium")) {
            drugItem = createNatrium(config);
        } else if (drug.equals("propanolamine")) {
            drugItem = createpropanolamine(config);
        } else if (drug.equals("cigarette")) {
            drugItem = createcigarette(config);
        } else if (drug.equals("glue")) {
            drugItem = createGlue(config);
        } else if (drug.equals("joint")) {
            drugItem = createjoint(config);
        } else if (drug.equals("longpapes")) {
            drugItem = createLongPapes(config);
        } else if (drug.equals("papes")) {
            drugItem = getPapeItem(config);
        } else if (drug.equals("zippo")) {
            drugItem = createZippo(config);
        } else if (drug.equals("weedseed")) {
            drugItem = getSuperSeedItem(config);
        } else if (drug.equals("cocaineseed")) {
            drugItem = getCocainePlantItem(config);
        } else if (drug.equals("tobaccoseed")) {
            drugItem = getTobaccoPlant(config);
        } else if (drug.equals("weed")) {
            drugItem = getSuperWheatItem(config);
        } else if (drug.equals("shroom")) {
            drugItem = getShroomItem(config);
        } else if (drug.equals("cocaine")) {
            drugItem = getCocaineItem(config);
        } else if (drug.equals("tobacco")) {
            drugItem = getTobaccoItem(config);
        } else if (drug.equals("xtc")) {
            drugItem = createXTC(config);
        } else if (drug.equals("isosafrole")) {
            drugItem = createIsoSafrole(config);
        } else if (drug.equals("piperonal")) {
            drugItem = createpiperonal(config);
        } else if (drug.equals("safrole")) {
            drugItem = createSafrole(config);
    } else {
            player.sendMessage("Invalid drug specified.");
            return true;
        }

        drugItem.setAmount(amount);

        player.getInventory().addItem(drugItem);
        player.sendMessage("You received " + amount + " " + drugname + ".");

        return true;
    }

    public static ItemStack createHydrogen(Configuration config) {
        ItemStack item = new ItemStack(Material.SUGAR);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("hydrogen_name", "§eHydrogen")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("hydrogen_lore", "§eYou need this to create drugs like LSD.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

    public static ItemStack createLSD(Configuration config) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("lsd_name", "§eLSD")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("lsd_lore", "§eYou can use it to get high.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

    public static ItemStack createLysergicAcid(Configuration config) {
        ItemStack item = new ItemStack(Material.GLASS_BOTTLE);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("lysergic_acid_name", "§eLysergic Acid")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("lysergic_acid_lore", "§eYou need it to create LSD.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

    public static ItemStack createNatrium(Configuration config) {
        ItemStack item = new ItemStack(Material.SUGAR);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("sodium_name", "§eSodium")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("sodium_lore", "§eYou need it to create parts of LSD.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

    public static ItemStack createpropanolamine(Configuration config) {
        ItemStack item = new ItemStack(Material.GLASS_BOTTLE);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("propanolamine_name", "§ePropanolamine acid")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("propanolamine_lore", "§eYou need it to create LSD.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

    public static ItemStack createcigarette(Configuration config) {
        ItemStack item = new ItemStack(Material.STICK);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("cigarette_lore", "§eYou can use this to get a nicotine rush.")));
        meta.setLore(lore);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("cigarette_name", "§eCigarette")));
        item.setItemMeta(meta);

        return item;
    }

    public static ItemStack createGlue(Configuration config) {
        ItemStack item = new ItemStack(Material.HONEY_BOTTLE);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("glue_bottle_name")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("glue_bottle_lore", "§eYou need it to create Long papes.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

    public static ItemStack createjoint(Configuration config) {
        ItemStack item = new ItemStack(Material.STICK);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("joint_lore", "§eYou can use this to get high.")));
        meta.setLore(lore);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("joint_name", "§eJoint")));
        item.setItemMeta(meta);

        return item;
    }

    public static ItemStack createLongPapes(Configuration config) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("long_papes_name", "§eLong Papes")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("long_papes_lore", "§eYou can use it to roll joints.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

    public static ItemStack getPapeItem(Configuration config) {
        ItemStack itemStack = new ItemStack(Material.PAPER);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("papes_name", "§ePapes")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("papes_lore", "§eYou can use it to roll cigarettes or to craft long papes.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    public static ItemStack createZippo(Configuration config) {
        ItemStack item = new ItemStack(Material.FLINT_AND_STEEL);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("zippo_name")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("zippo_lore")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

    private ItemStack getSuperSeedItem(Configuration config) {
        ItemStack itemStack = new ItemStack(Material.WHEAT_SEEDS);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("weed_seed_name", "§eWeed Seed")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("weed_seed_lore", "§eYou can plant this seed to create new Weed")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private ItemStack getCocainePlantItem(Configuration config) {
        ItemStack itemStack = new ItemStack(Material.WHEAT_SEEDS);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_seed_name", "§eCocaine Seed")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_seed_lore", "§eYou can use this seed to create new cocaine.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private ItemStack getTobaccoPlant(Configuration config) {
        ItemStack itemStack = new ItemStack(Material.WHEAT_SEEDS);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("tobacco_seed_name", "§eTobacco Seed")));
        List<String> lore = new ArrayList<>();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("tobacco_seed_lore", "§eYou can use this seed to create new Tobacco plant.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    public ItemStack getSuperWheatItem(Configuration config) {
        ItemStack itemStack = new ItemStack(Material.WHEAT, 1);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("weed_name", "§eWeed")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("weed_lore", "§eYou can use it to roll a joint.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private ItemStack getShroomItem(Configuration config) {
        ItemStack itemStack = new ItemStack(Material.RED_MUSHROOM);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("shroom_name", "§eShroom")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("shroom_lore", "§eYou can use it to get high.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private ItemStack getCocaineItem(Configuration config) {
        ItemStack itemStack = new ItemStack(Material.SUGAR, 1);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_name", "§eCocaine")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("cocaine_lore", "§eYou can consume it to feel high.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private ItemStack getTobaccoItem(Configuration config) {
        ItemStack itemStack = new ItemStack(Material.WHEAT, 1);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("tobacco_name", "§eTobacco")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("tobacco_lore", "§eYou can roll cigarettes with it.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }
    private ItemStack createXTC(Configuration config) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("xtc_name", "§eEcstasy")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("xtc_lore", "§eYou can use it to get high.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }
    public  ItemStack createIsoSafrole(Configuration config) {
        ItemStack item = new ItemStack(Material.SUGAR);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("isosafrole_name", "§eIsosafrole")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("isosafrole_lore", "§eYou need it to create XTC.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }
    public  ItemStack createpiperonal(Configuration config) {
        ItemStack item = new ItemStack(Material.SUGAR);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("piperonal_name", "§ePiperonal")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("piperonal_lore", "§eYou need it to create parts of XTC.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }
    public  ItemStack createSafrole(Configuration config) {
        ItemStack item = new ItemStack(Material.SUGAR);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("safrole_name", "§eSafrole")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("safrole_lore", "§eYou need it to create parts of XTC.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 3 && args[1].equalsIgnoreCase("ecstasy")) {
            completions.add("IsoSafrole");
            completions.add("safrole");
            completions.add("piperonal");
            completions.add("XTC");
        } else if (args.length == 3 && args[1].equalsIgnoreCase("lsd")) {
            completions.add("Hydrogen");
            completions.add("LSD");
            completions.add("Lysergicacid");
            completions.add("propanolamine");
            completions.add("Sodium");
        } else if (args.length == 3 && args[1].equalsIgnoreCase("cigarette")) {
            completions.add("Cigarette");
            completions.add("papes");
            completions.add("Tobacco");
            completions.add("TobaccoSeed");
            completions.add("Zippo");
        } else if (args.length == 3 && args[1].equalsIgnoreCase("weed")) {
            completions.add("Glue");
            completions.add("Joint");
            completions.add("Longpapes");
            completions.add("Weed");
            completions.add("WeedSeed");
            completions.add("Zippo");
        } else if (args.length == 3 && args[1].equalsIgnoreCase("cocaine")) {
            completions.add("Cocaine");
            completions.add("CocaineSeed");
        } else if (args.length == 3 && args[1].equalsIgnoreCase("shrooms")) {
            completions.add("Shroom");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            completions.add("cigarette");
            completions.add("cocaine");
            completions.add("ecstasy");
            completions.add("lsd");
            completions.add("shrooms");
            completions.add("weed");
        } else if (args.length == 1 && "drugs".startsWith(args[0].toLowerCase())) {
            completions.add("give");
        }
        return completions;
    }
}
