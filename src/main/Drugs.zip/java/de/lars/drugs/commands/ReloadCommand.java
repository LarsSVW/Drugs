package de.lars.drugs.commands;

import de.lars.drugs.Drugs;
import de.lars.drugs.config.Configuration;
import de.lars.drugs.crafting.ZippoCrafting;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

public class ReloadCommand implements CommandExecutor {

    private final Drugs plugin;
    private final Configuration config;
    public ReloadCommand(Drugs plugin, Configuration config) {
        this.config = config;
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("Drugs.reload")) {
            sender.sendMessage(ChatColor.RED + "You do not have permission to use this command.");
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            togglePlugin(sender, plugin, config);
        } else {
            sender.sendMessage(ChatColor.RED + "Usage: /drl reload");
        }

        return true;
    }

    public void togglePlugin(CommandSender sender, Drugs plugin, Configuration config) {
        plugin.getServer().getPluginManager().disablePlugin(plugin);
        sender.sendMessage("§a§l§nPlugin Drugs by Lars_SVW reload started.");
        Bukkit.clearRecipes();
        plugin.getServer().getPluginManager().enablePlugin(plugin);
        sender.sendMessage("§a§l§nPlugin Drugs by Lars_SVW reload finished");
    }
    }
