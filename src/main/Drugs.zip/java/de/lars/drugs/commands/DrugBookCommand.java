package de.lars.drugs.commands;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;

import java.util.ArrayList;
import java.util.List;

public class DrugBookCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can execute this command.");
            return true;
        }

        Player player = (Player) sender;

        ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        BookMeta bookMeta = (BookMeta) book.getItemMeta();
        bookMeta.setTitle(ChatColor.DARK_GREEN + "Drug Book");
        bookMeta.setAuthor(player.getName());

        List<String> pages = new ArrayList<>();

        List<String> sentences = new ArrayList<>();
        sentences.add("§5§l§nDrugs by Lars_SVW");
        sentences.add("§7In this book you will learn how to get/craft different drugs.");
        sentences.add("§5§l§nDrug Commands §7/drug give DRUG AMOUNT §8/drugbook");
        sentences.add("§5§l§nAll about Weed §7You can get weed seeds by mining regular grass. You can then plant and harvest these like normal wheat.");
        sentences.add("§5§l§nAll about Joints §7You craft joints by making weed in the middle of a workbench and long papes around the outside.");
        sentences.add("§5§l§nAll about Cocaine §7You get the cocaine seeds by breaking down normal grass and planting it.");
        sentences.add("§5§l§nAll about Tobacco §7You get tobacco seeds by mining normal grass and then planting them.");
        sentences.add("§5§l§nAll about Cigarettes §7You craft cigarettes by makin tobacco in the middle of a workbench and papes around it.");
        sentences.add("§5§l§nAll about Papes §7You craft papes by placing 3 sugar canes in a horizontal row in the crafting table.");
        sentences.add("§5§l§nAll about Long Papes §7You craft long papes by placing papes in the corner on the bottom left and rigt and in the bottom row mid you need to place glue  in the crafting table.");
        sentences.add("§5§l§nAll about Glue §7You can craft glue Like a normal Glassbottle but you have to put in the middle of the crafting table one slime.");
        sentences.add("§5§l§nAll about Shrooms §7You can get shrooms by mining red mushrooms.");
        sentences.add("§5§l§nAll about LSD §7In order to craft LSD you have to put in Propanolamine in the top left and bottom right of a crafting table, sodium has to be in the middle of the crafting table and LysergicAcid has to be in the top left and bottom right.");
        sentences.add("§5§l§nAll about Sodium §7To craft sodium you have to make a sugarcane in each corner and a dandelion in the middle.");
        sentences.add("§5§l§nAll about Hydrogen §7To create hydrogen you have to make a torch in the middle of the workbench in the bottom row and a bucket of water directly above the torch.");
        sentences.add("§5§l§nAll about Proanolamine §7To craft propanolamine you have to put hydrogen in the top left and top middle and middle of the workbench and sodium in the top right.");
        sentences.add("§5§l§nAll about LysergicAcid §7In order to craft LysergicAcid, sodium must be in every corner of the workbench and sodium must be in the middle, otherwise hydrogen everywhere.");
        sentences.add("§5§l§nAll about Ecstasy §7To craft XTC you must craft in the following order: IPS, PPS, IIS. I = isosafrole, P = piperonal, S = safrole.");
        sentences.add("§5§l§nAll about Isosarole §7To craft Isosafrole you have to but Safrole in the last row.");
        sentences.add("§5§l§nAll about Safrole §7To craft Safrole you must craft in the following order: ES, Es,S. E=Emerlad, S=Sweet Berries");
        sentences.add("§5§l§nAll about Piperonal §7To craft Piperonal you must craft in the following order: DS, DS, D.  D=Diamonds, S=Sugar");

        int sentencesPerPage = 100;
        int currentPage = 1;
        int sentenceCount = 0;

        for (String sentence : sentences) {
            if (sentenceCount % sentencesPerPage == 0) {
                pages.add(ChatColor.BLUE + "§5§lDrugbook. From the Plugin Drugs ");
                currentPage++;
            }
            pages.add(ChatColor.GRAY + sentence);
            sentenceCount++;
        }

        bookMeta.setPages(pages);
        book.setItemMeta(bookMeta);
        player.getInventory().addItem(book);

        player.sendMessage("You received the Drugbook.");

        return true;
    }
}