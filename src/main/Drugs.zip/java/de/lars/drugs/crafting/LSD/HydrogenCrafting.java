package de.lars.drugs.crafting.LSD;

import de.lars.drugs.Drugs;
import de.lars.drugs.config.Configuration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class HydrogenCrafting {
    public static void registerRecipes(Drugs plugin, Configuration config) {
        NamespacedKey key = new NamespacedKey(plugin, "hydrogen_recipe");
        ShapedRecipe recipe = new ShapedRecipe(key, createHydrogen(config));

        recipe.shape("   ", " W ", " T ");


        recipe.setIngredient('W', Material.WATER_BUCKET);
        recipe.setIngredient('T', Material.TORCH);


        Bukkit.addRecipe(recipe);
    }

    public static ItemStack createHydrogen(Configuration config) {
        ItemStack item = new ItemStack(Material.SUGAR);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("hydrogen_name", "§eHydrogen")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("hydrogen_lore", "§eYou need this to create drugs like LSD.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

}
