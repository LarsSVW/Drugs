package de.lars.drugs.crafting;

import de.lars.drugs.Drugs;
import de.lars.drugs.config.Configuration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class LongPapeCrafting {
    public static void registerRecipes(Drugs plugin, Configuration config) {
        NamespacedKey key = new NamespacedKey(plugin, "long_pape_recipe");
        ShapedRecipe recipe = new ShapedRecipe(key, createLongPapes(config));

        recipe.shape("   ", "   ", "PGP");


        recipe.setIngredient('G', new RecipeChoice.ExactChoice(GlueRecipeCrafting.createGlue(config)));
        recipe.setIngredient('P', new RecipeChoice.ExactChoice(PapeCrafting.getPapeItem(1, config)));


        Bukkit.addRecipe(recipe);
    }

    public static ItemStack createLongPapes(Configuration config) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("long_papes_name", "§eLong Papes")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("long_papes_lore", "§eYou can use it to roll joints.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }


}
