package de.lars.drugs.crafting;

import de.lars.drugs.Drugs;
import de.lars.drugs.config.Configuration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class GlueRecipeCrafting {
    public static void registerRecipes(Drugs plugin, Configuration config) {
        NamespacedKey key = new NamespacedKey(plugin, "glue_recipe");
        ShapedRecipe recipe = new ShapedRecipe(key, createGlue(config));

        recipe.shape("ABC", "DEF", "GHI");


        recipe.setIngredient('A', Material.getMaterial(config.getString("glue_material_a", "AIR")));
        recipe.setIngredient('B', Material.getMaterial(config.getString("glue_material_b", "AIR")));
        recipe.setIngredient('C', Material.getMaterial(config.getString("glue_material_c", "AIR")));
        recipe.setIngredient('D', Material.getMaterial(config.getString("glue_material_d", "AIR")));
        recipe.setIngredient('E', Material.getMaterial(config.getString("glue_material_e", "AIR")));
        recipe.setIngredient('F', Material.getMaterial(config.getString("glue_material_f", "AIR")));
        recipe.setIngredient('G', Material.getMaterial(config.getString("glue_material_g", "AIR")));
        recipe.setIngredient('H', Material.getMaterial(config.getString("glue_material_h", "AIR")));
        recipe.setIngredient('I', Material.getMaterial(config.getString("glue_material_i", "AIR")));


        Bukkit.addRecipe(recipe);
    }

    public static ItemStack createGlue(Configuration config) {
        ItemStack item = new ItemStack(Material.HONEY_BOTTLE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("glue_bottle_name")));
        List<String> lore = new ArrayList<>();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("glue_bottle_lore", "§eYou need it to create Long papes.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }
}
