package de.lars.drugs.crafting;

import de.lars.drugs.Drugs;
import de.lars.drugs.config.Configuration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class JointCrafting {
    private Configuration config;
    public JointCrafting(Configuration config){
        this.config = config;
    }
    public static void registerRecipes(Drugs plugin, Configuration config) {
        NamespacedKey key = new NamespacedKey(plugin, "joint");
        ShapedRecipe recipe = new ShapedRecipe(key, createjoint(config));

        recipe.shape("PPP", "PWP", "PPP");


        recipe.setIngredient('P', new RecipeChoice.ExactChoice(LongPapeCrafting.createLongPapes(config)));
        recipe.setIngredient('W', new RecipeChoice.ExactChoice(getweed(config)));


        Bukkit.addRecipe(recipe);
    }

    public static ItemStack createjoint(Configuration config) {
        ItemStack item = new ItemStack(Material.STICK);
        ItemMeta meta = item.getItemMeta();
        List<String> lore = new ArrayList<>();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("joint_lore", "§eYou can use this to get high.")));
        meta.setLore(lore);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("joint_name", "§eJoint")));
        item.setItemMeta(meta);

        return item;
    }

    public static ItemStack getweed(Configuration config) {
        ItemStack item = new ItemStack(Material.WHEAT);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("weed_name", "§eWeed")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("weed_lore", "§eYou can use it to roll a joint.")));
        meta.setLore(lore);
        item.setItemMeta(meta);
        meta.setCustomModelData(00001);

        return item;
    }

}
