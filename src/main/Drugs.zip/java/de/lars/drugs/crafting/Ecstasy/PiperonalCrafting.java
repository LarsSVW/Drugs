package de.lars.drugs.crafting.Ecstasy;

import de.lars.drugs.Drugs;
import de.lars.drugs.config.Configuration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class PiperonalCrafting {
    public static void registerRecipes(Drugs plugin, Configuration config) {
        NamespacedKey key = new NamespacedKey(plugin, "piperonal_recipe");
        ShapedRecipe recipe = new ShapedRecipe(key, createpiperonal(config));

        recipe.shape("DS ", "DS ", "D  ");


        recipe.setIngredient('D', Material.DIAMOND);
        recipe.setIngredient('S', Material.SUGAR);


        Bukkit.addRecipe(recipe);
    }

    public static ItemStack createpiperonal(Configuration config) {
        ItemStack item = new ItemStack(Material.SUGAR);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("piperonal_name", "§ePiperonal")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("piperonal_lore", "§eYou need it to create parts of XTC.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }
}
