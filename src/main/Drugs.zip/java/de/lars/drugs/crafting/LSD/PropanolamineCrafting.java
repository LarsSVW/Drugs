package de.lars.drugs.crafting.LSD;

import de.lars.drugs.Drugs;
import de.lars.drugs.config.Configuration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class PropanolamineCrafting {
    public static void registerRecipes(Drugs plugin, Configuration config) {
        NamespacedKey key = new NamespacedKey(plugin, "propanolamine_recipe");
        ShapedRecipe recipe = new ShapedRecipe(key, createpropanolamine(config));

        recipe.shape("HHN", " H ", "   ");


        recipe.setIngredient('H', new RecipeChoice.ExactChoice(HydrogenCrafting.createHydrogen(config)));
        recipe.setIngredient('N', new RecipeChoice.ExactChoice(NatriumCrafting.createNatrium(config)));


        Bukkit.addRecipe(recipe);
    }

    public static ItemStack createpropanolamine(Configuration config) {
        ItemStack item = new ItemStack(Material.GLASS_BOTTLE);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("propanolamine_name", "§ePropanolamine acid") ));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("propanolamine_lore", "§eYou need it to create LSD.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }
}

