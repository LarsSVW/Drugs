package de.lars.drugs.crafting;

import de.lars.drugs.Drugs;
import de.lars.drugs.config.Configuration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ZippoCrafting {

    public static void registerRecipes(Drugs plugin, Configuration config) {
        NamespacedKey key = new NamespacedKey(plugin, "zippo_recipe");
        ShapedRecipe recipe = new ShapedRecipe(key, createZippo(config));

        recipe.shape("ABC", "DEF", "GHI");


        recipe.setIngredient('A', Material.getMaterial(config.getString("zippo_material_a", "AIR")));
        recipe.setIngredient('B', Material.getMaterial(config.getString("zippo_material_b", "AIR")));
        recipe.setIngredient('C', Material.getMaterial(config.getString("zippo_material_c", "AIR")));
        recipe.setIngredient('D', Material.getMaterial(config.getString("zippo_material_d", "AIR")));
        recipe.setIngredient('E', Material.getMaterial(config.getString("zippo_material_e", "AIR")));
        recipe.setIngredient('F', Material.getMaterial(config.getString("zippo_material_f", "AIR")));
        recipe.setIngredient('G', Material.getMaterial(config.getString("zippo_material_g", "AIR")));
        recipe.setIngredient('H', Material.getMaterial(config.getString("zippo_material_h", "AIR")));
        recipe.setIngredient('I', Material.getMaterial(config.getString("zippo_material_i", "AIR")));

        Bukkit.addRecipe(recipe);
    }

    public static ItemStack createZippo(Configuration config) {
        ItemStack item = new ItemStack(Material.FLINT_AND_STEEL);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("zippo_name")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("zippo_lore")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }


}