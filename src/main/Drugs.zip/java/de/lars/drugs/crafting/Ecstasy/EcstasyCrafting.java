package de.lars.drugs.crafting.Ecstasy;

import de.lars.drugs.Drugs;
import de.lars.drugs.config.Configuration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class EcstasyCrafting {
    public static void registerRecipes(Drugs plugin, Configuration config) {
        NamespacedKey key = new NamespacedKey(plugin, "Ecstasy_recipe");
        ShapedRecipe recipe = new ShapedRecipe(key, createXTC(config));

        recipe.shape("IPS", "PPS", "IIS");


        recipe.setIngredient('S', new RecipeChoice.ExactChoice(SafroleCrafting.createSafrole(config)));
        recipe.setIngredient('P', new  RecipeChoice.ExactChoice(PiperonalCrafting.createpiperonal(config)));
        recipe.setIngredient('I', new RecipeChoice.ExactChoice(IsoSafroleCrafting.createIsoSafrole(config)));


        Bukkit.addRecipe(recipe);
    }

    private static ItemStack createXTC(Configuration config) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("xtc_name", "§eEcstasy")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("xtc_lore", "§eYou can use it to get high.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }
}