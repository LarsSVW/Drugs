package de.lars.drugs.crafting;

import de.lars.drugs.Drugs;
import de.lars.drugs.config.Configuration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PapeCrafting {

    private final Drugs plugin;
    private Configuration config;

    public PapeCrafting(Drugs plugin, Configuration config)
    {
        this.config = config;
        this.plugin = plugin;
    }

    public void registerRecipe() {
        ItemStack resultItem = getPapeItem(1, config);

        ShapedRecipe recipe = new ShapedRecipe(new NamespacedKey(plugin, "pape_recipe"), resultItem);
        recipe.setIngredient('A', Material.getMaterial(config.getString("pape_material_a", "AIR")));
        recipe.setIngredient('B', Material.getMaterial(config.getString("pape_material_b", "AIR")));
        recipe.setIngredient('C', Material.getMaterial(config.getString("pape_material_c", "AIR")));
        recipe.setIngredient('D', Material.getMaterial(config.getString("pape_material_d", "AIR")));
        recipe.setIngredient('E', Material.getMaterial(config.getString("pape_material_e", "AIR")));
        recipe.setIngredient('F', Material.getMaterial(config.getString("pape_material_f", "AIR")));
        recipe.setIngredient('G', Material.getMaterial(config.getString("pape_material_g", "AIR")));
        recipe.setIngredient('H', Material.getMaterial(config.getString("pape_material_h", "AIR")));
        recipe.setIngredient('I', Material.getMaterial(config.getString("pape_material_i", "AIR")));

        Bukkit.addRecipe(recipe);
    }

    public static ItemStack getPapeItem(int amount, Configuration config) {
        ItemStack itemStack = new ItemStack(Material.PAPER, amount);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("papes_name", "§ePapes")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("papes_lore", "§eYou can use it to roll cigarettes or to craft long papes.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }
}