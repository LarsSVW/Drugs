package de.lars.drugs.crafting.LSD;

import de.lars.drugs.Drugs;
import de.lars.drugs.config.Configuration;
import jdk.nashorn.internal.runtime.regexp.joni.Config;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class NatriumCrafting {
    public static void registerRecipes(Drugs plugin, Configuration config) {
        NamespacedKey key = new NamespacedKey(plugin, "natrium_recipe");
        ShapedRecipe recipe = new ShapedRecipe(key, createNatrium(config));

        recipe.shape("S S", " D ", "S S");


        recipe.setIngredient('S', Material.SUGAR_CANE);
        recipe.setIngredient('D', Material.DANDELION);


        Bukkit.addRecipe(recipe);
    }

    public static ItemStack createNatrium(Configuration config) {
        ItemStack item = new ItemStack(Material.SUGAR);
        ItemMeta meta = item.getItemMeta();
        meta.addEnchant(Enchantment.DURABILITY, 3, true);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("sodium_name", "§eSodium")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("sodium_lore", "§eYou need it to create parts of LSD.")));
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }


}
