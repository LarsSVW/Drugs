package de.lars.drugs;

import de.lars.drugs.commands.DrugBookCommand;
import de.lars.drugs.commands.DrugsCommand;
import de.lars.drugs.commands.ReloadCommand;
import de.lars.drugs.config.Configuration;
import de.lars.drugs.crafting.*;
import de.lars.drugs.crafting.Ecstasy.EcstasyCrafting;
import de.lars.drugs.crafting.Ecstasy.IsoSafroleCrafting;
import de.lars.drugs.crafting.Ecstasy.PiperonalCrafting;
import de.lars.drugs.crafting.Ecstasy.SafroleCrafting;
import de.lars.drugs.crafting.LSD.*;
import de.lars.drugs.listener.DrugEffectListener.*;
import de.lars.drugs.listener.DrugListener.CocaineListener;
import de.lars.drugs.listener.DrugListener.TobaccoListener;
import de.lars.drugs.listener.GrassBreakListener;
import de.lars.drugs.listener.RenameBlockListener;
import de.lars.drugs.listener.ShroomBreakListener;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.CommandExecutor;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Drugs extends JavaPlugin implements Listener {
    private Configuration config;
    private JointCrafting jointCrafting;
    private GlueRecipeCrafting glueRecipeCrafting;
    private PapeCrafting papeCrafting;
    private LongPapeCrafting longPapeCrafting;
    private CigaretteCrafting cigaretteCrafting;
    private ZippoCrafting zippoCrafting;
    private NatriumCrafting natriumCrafting;
    private PropanolamineCrafting propanolamineCrafting;
    private LysergicAcidCrafting lysergicAcidCrafting;
    private HydrogenCrafting hydrogenCrafting;
    private LSDCrafting lsdCrafting;
    private EcstasyCrafting ecstasyCrafting;
    private IsoSafroleCrafting isoSafroleCrafting;
    private PiperonalCrafting piperonalCrafting;
    private SafroleCrafting safroleCrafting;


    @Override
    public void onEnable() {
        this.config = new Configuration(new File(getDataFolder(), "config.yml"));
        this.config.setTemplateName("/config.yml");
        this.config.load();
        getServer().getPluginManager().registerEvents(new RenameBlockListener(config), this);
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(new CocaineListener(this,config), this);
        getServer().getPluginManager().registerEvents(new WeedEffectListener(config), this);
        getServer().getPluginManager().registerEvents(new GrassBreakListener(config), this);
        getServer().getPluginManager().registerEvents(new ShroomBreakListener(config), this);
        getServer().getPluginManager().registerEvents(new CocaineListener(this,config), this);
        getServer().getPluginManager().registerEvents(new CocaineEffectListener(config), this);
        getServer().getPluginManager().registerEvents(new TobaccoEffectListener(config),this);
        getServer().getPluginManager().registerEvents(new TobaccoListener(this, config), this);
        getServer().getPluginManager().registerEvents(new ShroomsEffectListener(config),this);
        getServer().getPluginManager().registerEvents(new LSDEffectListener(config), this);
        getServer().getPluginManager().registerEvents(new EcstasyEffectListener(config), this);
        getCommand("drugs").setExecutor((CommandExecutor) new DrugsCommand(config));
        getCommand("drugbook").setExecutor((CommandExecutor) new DrugBookCommand());
        getCommand("drl").setExecutor((CommandExecutor) new ReloadCommand(this, config));
        zippoCrafting = new ZippoCrafting();
        ZippoCrafting.registerRecipes(this, config);
        papeCrafting = new PapeCrafting(this, config);
        papeCrafting.registerRecipe();
        jointCrafting = new JointCrafting(config);
        JointCrafting.registerRecipes(this, config);
        cigaretteCrafting = new CigaretteCrafting(config);
        CigaretteCrafting.registerRecipes(this, config);
        glueRecipeCrafting = new GlueRecipeCrafting();
        GlueRecipeCrafting.registerRecipes(this, config);
        longPapeCrafting = new LongPapeCrafting();
        LongPapeCrafting.registerRecipes(this, config);
        natriumCrafting = new NatriumCrafting();
        NatriumCrafting.registerRecipes(this, config);
        hydrogenCrafting = new HydrogenCrafting();
        HydrogenCrafting.registerRecipes(this, config);
        lsdCrafting = new LSDCrafting();
        LSDCrafting.registerRecipes(this, config);
        lysergicAcidCrafting = new LysergicAcidCrafting();
        LysergicAcidCrafting.registerRecipes(this, config);
        propanolamineCrafting = new PropanolamineCrafting();
        PropanolamineCrafting.registerRecipes(this, config);
        ecstasyCrafting = new EcstasyCrafting();
        EcstasyCrafting.registerRecipes(this, config);
        isoSafroleCrafting = new IsoSafroleCrafting();
        IsoSafroleCrafting.registerRecipes(this, config);
        piperonalCrafting = new PiperonalCrafting();
        PiperonalCrafting.registerRecipes(this, config);
        safroleCrafting = new SafroleCrafting();
        SafroleCrafting.registerRecipes(this,config);
        getServer().getPluginManager().registerEvents(new CocaineListener(this, config), this);
    }
    @Override
    public void onDisable() {

    }
    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getItemInHand();
        if (item != null && item.getType() == Material.WHEAT_SEEDS && item.hasItemMeta()) {
            ItemMeta itemMeta = item.getItemMeta();
            if (itemMeta.hasDisplayName() && itemMeta.getDisplayName().equals(ChatColor.translateAlternateColorCodes('&', config.getString("weed_seed_name", "§eWeed Seed")))) {
                Block block = event.getBlock();
                block.setMetadata("weedseed", new FixedMetadataValue(this, true));
            }
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (block.getType() == Material.WHEAT && block.hasMetadata("weedseed")) {
            boolean isFullyGrown = isFullyGrown(block);
            event.setCancelled(true);
            block.setType(Material.AIR);
            if (isFullyGrown) {
                block.getWorld().dropItemNaturally(block.getLocation(), getSuperWheatItem());
                block.getWorld().dropItemNaturally(block.getLocation(), getSuperSeedItem(2));
            } else {
                block.getWorld().dropItemNaturally(block.getLocation(), getSuperSeedItem(1));
            }
            block.removeMetadata("weedseed", this);
        }
    }

    private boolean isFullyGrown(Block block) {
        BlockData blockData = block.getBlockData();
        if (blockData instanceof Ageable) {
            Ageable ageable = (Ageable) blockData;
            return ageable.getAge() == ageable.getMaximumAge();
        }
        return false;
    }

    public ItemStack getSuperWheatItem() {
        ItemStack itemStack = new ItemStack(Material.WHEAT, 1);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("weed_name", "§eWeed")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("weed_lore", "§eYou can use it to roll a joint.")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private ItemStack getSuperSeedItem(int amount) {
        ItemStack itemStack = new ItemStack(Material.WHEAT_SEEDS, amount);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', config.getString("weed_seed_name", "§eWeed Seed")));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', config.getString("weed_seed_lore", "§eYou can use this seed to create new Weed!")));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

}

